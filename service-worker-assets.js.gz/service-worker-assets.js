self.assetsManifest = {
  "version": "GODMGHHu",
  "assets": [
    {
      "hash": "sha256-47DEQpj8HBSa+/TImW+5JCeuQeRkm5NMpJWZG3hSuFU=",
      "url": ".nojekyll"
    },
    {
      "hash": "sha256-Ps2EqpQtAHIfcMzWG8A9KuCME6yn86porJbKiOVBYYc=",
      "url": "404.html"
    },
    {
      "hash": "sha256-poV4ELCt5FQ5ItXigsTvFDRnFsaBxnHpwAAXEZ0ho7k=",
      "url": "MudBlazorGitHubPages.styles.css"
    },
    {
      "hash": "sha256-UVy3L6kXaa89JN6tg+EbiLCuVLpkmxOoG6sAi7Bb9uc=",
      "url": "_content/BlazorWasmPreRendering.Build/BlazorWasmPreRendering.Build.lfyg69o9wu.lib.module.js"
    },
    {
      "hash": "sha256-TSgzDIY4qdWvjvfBaUSrnerVt2+FjH4cXGlPrxEz1C0=",
      "url": "_content/MudBlazor/MudBlazor.min.css"
    },
    {
      "hash": "sha256-hylTyzoFC8Kp1f0FRqBY1LUV5GLhjEZGZbvrFnkZ1Tw=",
      "url": "_content/MudBlazor/MudBlazor.min.js"
    },
    {
      "hash": "sha256-OaMAAd5n7ORfyur5e3QIyEVKJ76MKIvwbg7/icnnYcU=",
      "url": "_framework/Blazored.LocalStorage.12n6dz54qr.wasm"
    },
    {
      "hash": "sha256-irG9pOzr0hwtNQbXTyOrch1c8QeUOn585mfhAXQtxvo=",
      "url": "_framework/Microsoft.AspNetCore.Components.69g5o23x2m.wasm"
    },
    {
      "hash": "sha256-BTHXkhy/9X3p+MX0/sm31OTLsBa/eASz8VZ7QmpdYzQ=",
      "url": "_framework/Microsoft.AspNetCore.Components.Forms.3qh9t4or2h.wasm"
    },
    {
      "hash": "sha256-SwoMPlHS05yT2/LjqTYV4nO5fDMfNfd6qGFDDIKUa9U=",
      "url": "_framework/Microsoft.AspNetCore.Components.Web.xxzncl2btm.wasm"
    },
    {
      "hash": "sha256-NdFiyBPTcBCX64Ql2gwC47tAWTnEUbYUXc8QVl9N/Qc=",
      "url": "_framework/Microsoft.AspNetCore.Components.WebAssembly.3ygwhsfi6w.wasm"
    },
    {
      "hash": "sha256-mkh91ACA/HqNQJbw1UqGLPzd8Hxo+uTbqOPhR4kOh2g=",
      "url": "_framework/Microsoft.Extensions.Configuration.Abstractions.y512lsaiix.wasm"
    },
    {
      "hash": "sha256-u50NX3RSpD+OK+2XVLJemO91EfJBLdGznULK6zgDKAg=",
      "url": "_framework/Microsoft.Extensions.Configuration.Binder.h9r51q08u4.wasm"
    },
    {
      "hash": "sha256-/jB8J7byRl8++Sms23uw7dTZtf4OYQ+9wprtBqLHzvg=",
      "url": "_framework/Microsoft.Extensions.Configuration.Json.6ap0l7oqnx.wasm"
    },
    {
      "hash": "sha256-f762ppC+IVk2CY6dCQujgjDfnpFXiEsDkjgGrQSyWaE=",
      "url": "_framework/Microsoft.Extensions.Configuration.ny2ucm7t9p.wasm"
    },
    {
      "hash": "sha256-7YwVRVQjk0W3tjnhwJItAZILHRYX+LKQ8iRYoGjf5Xg=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.Abstractions.f9ku9u5u88.wasm"
    },
    {
      "hash": "sha256-t+RV090mInmcuQIlc498uXnF8wtK1MRNcmC72iNVUZI=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.t7f5r90yql.wasm"
    },
    {
      "hash": "sha256-tnMHqb6BpI1Jj9M9WNSAAJzzxHrQgov/aSXbFqc+xzk=",
      "url": "_framework/Microsoft.Extensions.Localization.Abstractions.ixsppbtym0.wasm"
    },
    {
      "hash": "sha256-6UgMJoVZBfDdfzYR0aKVK6BWArxpXC1qiQDDjiXw/L4=",
      "url": "_framework/Microsoft.Extensions.Localization.bvn14pws96.wasm"
    },
    {
      "hash": "sha256-EFH3JxUgxnGjjBDWquxBSTek6QAg8HPezdjvUVyyQMY=",
      "url": "_framework/Microsoft.Extensions.Logging.Abstractions.o64rh0zm5x.wasm"
    },
    {
      "hash": "sha256-9x8FXDisdekP0Dbg8khNrE+Oocnngh9johtSRZyrZPk=",
      "url": "_framework/Microsoft.Extensions.Logging.bvp0h3knwz.wasm"
    },
    {
      "hash": "sha256-OVRNJEKe9y6xOoqXrWmX+sOMl/uyQiSc5cYEYWMiUY0=",
      "url": "_framework/Microsoft.Extensions.Options.7oidopj7m4.wasm"
    },
    {
      "hash": "sha256-Il7b7g4iQZWSTrBCdBft+EmS4u4r3VgzpqSIb4bfvTI=",
      "url": "_framework/Microsoft.Extensions.Primitives.a5mjza44y9.wasm"
    },
    {
      "hash": "sha256-vScvGCGFOzwoTsy7VKfMU9uuEskXbOdWabIc80iDa9g=",
      "url": "_framework/Microsoft.JSInterop.WebAssembly.9tiedlnvko.wasm"
    },
    {
      "hash": "sha256-tnAHZ/qsh7BK04vYkkW0XreHvqPwoum98+hfS+tQY3Y=",
      "url": "_framework/Microsoft.JSInterop.eyaxz6adjz.wasm"
    },
    {
      "hash": "sha256-SU0lC/N/eJWugr7ME26doxMF3q75epJff0wN4acuUg8=",
      "url": "_framework/MudBlazor.jljyjag3p3.wasm"
    },
    {
      "hash": "sha256-LecrjPMXgGIIAQTZj7Q/EfCREqCzMbq/wQGPG5Avlr8=",
      "url": "_framework/MudBlazorGitHubPages.5a0fsz3o0f.wasm"
    },
    {
      "hash": "sha256-oaUyoVo2a89AwFRLViIDIdBnhpi17mAo03uxs1QLd2g=",
      "url": "_framework/Serilog.Sinks.BrowserConsole.x47anjwz3v.wasm"
    },
    {
      "hash": "sha256-2+Qj4wYEFirLYjCHxUJSxDTpPzCq6Z0gVmrMrcO7g9c=",
      "url": "_framework/Serilog.ti8gg3xy57.wasm"
    },
    {
      "hash": "sha256-xMF0eauQ5DkSzUozHLFFMQnL6DSJO09nJLtgag+Dzbw=",
      "url": "_framework/System.8rv0tdtrxz.wasm"
    },
    {
      "hash": "sha256-40NqYjQwd25CJVtEdIVuKWGDcM2tfGc7fMxlQ2fbmy4=",
      "url": "_framework/System.Collections.Concurrent.buietk6a3u.wasm"
    },
    {
      "hash": "sha256-CW0XbITlmL+M/PGaIyk2Di9+I2ZncDiUiPN62RDp5xw=",
      "url": "_framework/System.Collections.Immutable.3xhlx5tqj3.wasm"
    },
    {
      "hash": "sha256-T5uSoaCuVrEoK66j6l1GThciRkaTSc/lokj6QtvCJxg=",
      "url": "_framework/System.Collections.NonGeneric.zf10c2ccao.wasm"
    },
    {
      "hash": "sha256-ijjeEbfNC2OlPfu308Dic4PzeBtw25E7AppHia8U1NA=",
      "url": "_framework/System.Collections.Specialized.itxxyjpqle.wasm"
    },
    {
      "hash": "sha256-Ghx7tbu8W8vgof8n3XKo/mRAxXkl6t1kJg7bkGQ+ymU=",
      "url": "_framework/System.Collections.afkulnnzjk.wasm"
    },
    {
      "hash": "sha256-U5Jd9oGyDhXgPZfBdkkVYJrEWAFvWO5cLdl5eBQX2p8=",
      "url": "_framework/System.ComponentModel.Annotations.dcb1q9ajig.wasm"
    },
    {
      "hash": "sha256-mpjgfeFf6tJgdFm+Cvebj/0GyL+GIarhoL8cQrPO/Tw=",
      "url": "_framework/System.ComponentModel.Primitives.6pddupjcz8.wasm"
    },
    {
      "hash": "sha256-CXowS7XzjK0o7sncMpE7xhiRXCL+QpVnspVL2KXzGKg=",
      "url": "_framework/System.ComponentModel.TypeConverter.ha12zp8yn0.wasm"
    },
    {
      "hash": "sha256-P2bTPhn46nReTKHreFG6K47nCeDru/fCwA+UWdaZUK4=",
      "url": "_framework/System.ComponentModel.rp2ud0tstw.wasm"
    },
    {
      "hash": "sha256-WnZlnIgKvB74lTljoYtvmCwxSxs3Uas9g/Tv7JTRGDU=",
      "url": "_framework/System.Console.mcibkdfytd.wasm"
    },
    {
      "hash": "sha256-FBW6K4TORa24v2L639DPjf309NTGkrj0iIqiJaPqcYA=",
      "url": "_framework/System.IO.Pipelines.wn1erg3up3.wasm"
    },
    {
      "hash": "sha256-eKLteuaz1VoUufCGLJqN2sSTbCNO2zNUEzvRhmm0IaY=",
      "url": "_framework/System.Linq.Expressions.803195wck0.wasm"
    },
    {
      "hash": "sha256-Bo2zbB5aChpm7hQetC44KDhewj5hYbhgfkIsBYbcGWc=",
      "url": "_framework/System.Linq.qnfrpvfaty.wasm"
    },
    {
      "hash": "sha256-z/QYwpls8A0orsj/ojT/lJJHkMbNLyxIb0u0RIJlvjc=",
      "url": "_framework/System.Memory.bp0h7ss33b.wasm"
    },
    {
      "hash": "sha256-+vqyxdE1+UA7vISnsC/CoYMA3LXzaLr7Eh0hQkgL3nw=",
      "url": "_framework/System.Net.Http.unyy781uvi.wasm"
    },
    {
      "hash": "sha256-QGfRxDDetU99gZZiBvpOeKywUoZ1QVAfJ0vfm6HWcb4=",
      "url": "_framework/System.Net.Primitives.om9mt4c0ro.wasm"
    },
    {
      "hash": "sha256-wcmlpe+jkCyBS3vavLw0cdDgRBV+rg0VDjRGkcGTaZs=",
      "url": "_framework/System.ObjectModel.7m6n1tcre6.wasm"
    },
    {
      "hash": "sha256-W7ql5PT3jTADEKT+RSCsMhUfj9pNlfQtgax4EgiArmg=",
      "url": "_framework/System.Private.CoreLib.3mc2i7smx3.wasm"
    },
    {
      "hash": "sha256-MtuZxZW9ttDrxgtuj6zvM2J5a8euEPEbL70GzzOhvPE=",
      "url": "_framework/System.Private.Uri.66jv6f9fhq.wasm"
    },
    {
      "hash": "sha256-fcbhHB7hDI448FbXH9oGRMD0YiK7sml91c0Cfomkn6c=",
      "url": "_framework/System.Runtime.InteropServices.JavaScript.lu7n7av6ff.wasm"
    },
    {
      "hash": "sha256-9Px1nQYl0ighFOCsd1f3CCg7jOU1rSaFOUjS42Hmim0=",
      "url": "_framework/System.Runtime.gdpmr6wgod.wasm"
    },
    {
      "hash": "sha256-SQ1+aS+lCxp43qhvbxWS01rhQfbvNeDSN0xyk2P9/Hc=",
      "url": "_framework/System.Text.Encodings.Web.hq94nfnuw2.wasm"
    },
    {
      "hash": "sha256-oRrmpH36sE34IKpbygJMZ+cGQuXnjUC4aojXl+9dSFk=",
      "url": "_framework/System.Text.Json.zfy4ibkbmx.wasm"
    },
    {
      "hash": "sha256-IswkNMgr7out1l+D/ciWw+6qcE48eci21+WgdGhs1EQ=",
      "url": "_framework/System.Text.RegularExpressions.y393jkudoi.wasm"
    },
    {
      "hash": "sha256-qpTsdttgwFKu3sCPl9Qw0nYZISOGaHpAJFTWUzt9Xzw=",
      "url": "_framework/System.Threading.6wxzpv4ki1.wasm"
    },
    {
      "hash": "sha256-sDPqXwLClhawwgXOpyF9h7YADDGHMWs9wqkG62ymAVk=",
      "url": "_framework/blazor.boot.json"
    },
    {
      "hash": "sha256-+vIfWRbrna1rF+s8xknbrluJxgPx4vfKB0WJ74HdICo=",
      "url": "_framework/blazor.webassembly.js"
    },
    {
      "hash": "sha256-N+/jRbIsqVbSKyrJpXTfko/MbGFn4mYhGgK+pW+zQ7o=",
      "url": "_framework/dotnet.js"
    },
    {
      "hash": "sha256-oBjTBMWipOBGg2SmgJr4yWw7x536rMCNCZgF62kqT0s=",
      "url": "_framework/dotnet.native.g0x6c0ef2o.js"
    },
    {
      "hash": "sha256-4ptaSuMaYa0iNAG18LqvGZ8OCphIGe/HHU9qtdKuFMc=",
      "url": "_framework/dotnet.native.mntfcnpyya.wasm"
    },
    {
      "hash": "sha256-yfXUv1l/B489E8p12JxUvxly0JvHL9CCsoZUDlfGH9c=",
      "url": "_framework/dotnet.runtime.drv0pr9n5o.js"
    },
    {
      "hash": "sha256-SZLtQnRc0JkwqHab0VUVP7T3uBPSeYzxzDnpxPpUnHk=",
      "url": "_framework/icudt_CJK.tjcz0u77k5.dat"
    },
    {
      "hash": "sha256-8fItetYY8kQ0ww6oxwTLiT3oXlBwHKumbeP2pRF4yTc=",
      "url": "_framework/icudt_EFIGS.tptq2av103.dat"
    },
    {
      "hash": "sha256-L7sV7NEYP37/Qr2FPCePo5cJqRgTXRwGHuwF5Q+0Nfs=",
      "url": "_framework/icudt_no_CJK.lfu7j35m59.dat"
    },
    {
      "hash": "sha256-+A9GJSL1F7E2tMCpF5MhfSLW2Gd35PbafP4B4Z7MEcE=",
      "url": "appsettings.json"
    },
    {
      "hash": "sha256-yis2dNdJ6e9R472mcuwUOsxBPCQX3snSMmHAL3zu2D8=",
      "url": "css/app.css"
    },
    {
      "hash": "sha256-4mWsDy3aHl36ZbGt8zByK7Pvd4kRUoNgTYzRnwmPHwg=",
      "url": "favicon.png"
    },
    {
      "hash": "sha256-DbpQaq68ZSb5IoPosBErM1QWBfsbTxpJqhU0REi6wP4=",
      "url": "icon-192.png"
    },
    {
      "hash": "sha256-oEo6d+KqX5fjxTiZk/w9NB3Mi0+ycS5yLwCKwr4IkbA=",
      "url": "icon-512.png"
    },
    {
      "hash": "sha256-1qGh4vvaI8rnuw5awa8DuOFSfYo10vPyA+xhDn7txCQ=",
      "url": "index.html"
    },
    {
      "hash": "sha256-VSQRX1zufPPfljeh63jtX4Vvpz7IiZ3mWL3FRcPG7gM=",
      "url": "manifest.webmanifest"
    }
  ]
};
