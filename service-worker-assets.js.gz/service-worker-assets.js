self.assetsManifest = {
  "version": "3UGaXJ+R",
  "assets": [
    {
      "hash": "sha256-47DEQpj8HBSa+/TImW+5JCeuQeRkm5NMpJWZG3hSuFU=",
      "url": ".nojekyll"
    },
    {
      "hash": "sha256-Ps2EqpQtAHIfcMzWG8A9KuCME6yn86porJbKiOVBYYc=",
      "url": "404.html"
    },
    {
      "hash": "sha256-poV4ELCt5FQ5ItXigsTvFDRnFsaBxnHpwAAXEZ0ho7k=",
      "url": "MudBlazorGitHubPages.styles.css"
    },
    {
      "hash": "sha256-UVy3L6kXaa89JN6tg+EbiLCuVLpkmxOoG6sAi7Bb9uc=",
      "url": "_content/BlazorWasmPreRendering.Build/BlazorWasmPreRendering.Build.lfyg69o9wu.lib.module.js"
    },
    {
      "hash": "sha256-pxoL0sR+rW8FeySiRHjFptIGusn0BFRre4j7xSLzJrY=",
      "url": "_content/MudBlazor/MudBlazor.min.css"
    },
    {
      "hash": "sha256-JIdvZz+p6bMt7bvlJ0UxWaJNf/8AADBtXlwwd75JwMM=",
      "url": "_content/MudBlazor/MudBlazor.min.js"
    },
    {
      "hash": "sha256-OaMAAd5n7ORfyur5e3QIyEVKJ76MKIvwbg7/icnnYcU=",
      "url": "_framework/Blazored.LocalStorage.12n6dz54qr.wasm"
    },
    {
      "hash": "sha256-/w5E7LJWBLa7so0LcXK/PLpE/fNwPErxJhlVfGasCAo=",
      "url": "_framework/Microsoft.AspNetCore.Components.Forms.x80val28il.wasm"
    },
    {
      "hash": "sha256-h9GyUb8vWLcAiCDULxHGLZLlN6c1ZLVzM97HqFVE5n4=",
      "url": "_framework/Microsoft.AspNetCore.Components.Web.z92snw2zcg.wasm"
    },
    {
      "hash": "sha256-E8o2osWNPnmgn3e788d/AR675YQkwYIzH/xa1tI3aQY=",
      "url": "_framework/Microsoft.AspNetCore.Components.WebAssembly.hzjrw661xu.wasm"
    },
    {
      "hash": "sha256-JUfcBeocwaKSB1i9nSZwKh5q7fCHh4aDaVTRSuPK3DA=",
      "url": "_framework/Microsoft.AspNetCore.Components.r4jwgkn9n7.wasm"
    },
    {
      "hash": "sha256-YnOkeYhr/iOwnkXRpzJYpiHANyDwxuxKNlK1lvXgZMQ=",
      "url": "_framework/Microsoft.Extensions.Configuration.Abstractions.y74duq3qds.wasm"
    },
    {
      "hash": "sha256-7j4HaXerydDch6RiAjfpPs2kK0wrI1ZpGAqNM0EQHE8=",
      "url": "_framework/Microsoft.Extensions.Configuration.Binder.2sq6w9l7g4.wasm"
    },
    {
      "hash": "sha256-X+g8Y9v8Xs3DURC3DvFf0BXk5Ll4hWN5k4Oc+3lBALE=",
      "url": "_framework/Microsoft.Extensions.Configuration.Json.this79iyc7.wasm"
    },
    {
      "hash": "sha256-m76PQKrQmHQWgoPu7yYdflnrb8entJiDM59LXo17sBw=",
      "url": "_framework/Microsoft.Extensions.Configuration.zuon1cps2j.wasm"
    },
    {
      "hash": "sha256-CoSn/A4WuJr3dOJXrWyxFYRUeF8jSqKnp9/CLIPLlQ0=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.Abstractions.az0k69v7u7.wasm"
    },
    {
      "hash": "sha256-rW0muBNtI+FY/WA4kKZ6KaamvExUL3czb1N7sbPc6K4=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.t4styidezf.wasm"
    },
    {
      "hash": "sha256-tnMHqb6BpI1Jj9M9WNSAAJzzxHrQgov/aSXbFqc+xzk=",
      "url": "_framework/Microsoft.Extensions.Localization.Abstractions.ixsppbtym0.wasm"
    },
    {
      "hash": "sha256-6UgMJoVZBfDdfzYR0aKVK6BWArxpXC1qiQDDjiXw/L4=",
      "url": "_framework/Microsoft.Extensions.Localization.bvn14pws96.wasm"
    },
    {
      "hash": "sha256-/lATVMaxjrO/7QTYnmE50qdHvr8l76pNE9v29HGzLeA=",
      "url": "_framework/Microsoft.Extensions.Logging.6vimitskgi.wasm"
    },
    {
      "hash": "sha256-fbD19XMFcHzFYLWPJ7gZT69PBsLIIf9XxvfH09/3y8w=",
      "url": "_framework/Microsoft.Extensions.Logging.Abstractions.v92sxplh8i.wasm"
    },
    {
      "hash": "sha256-vc8CWywpPFGVlV1s6BzM2iogrTlr8xfH22VaInhkpU4=",
      "url": "_framework/Microsoft.Extensions.Options.v5r7rgvi6o.wasm"
    },
    {
      "hash": "sha256-L5NQ4Q3qCOQCVq4fdxJDVX9+tmbCgm5IufwAOUFf37o=",
      "url": "_framework/Microsoft.Extensions.Primitives.330fdynik0.wasm"
    },
    {
      "hash": "sha256-52li3rv6uQT4TFUoqRLiSC0ztkV28vVbI7T+3qPRYzY=",
      "url": "_framework/Microsoft.JSInterop.1moab4w2ry.wasm"
    },
    {
      "hash": "sha256-EzPimVxYUyvc5hlmFOvopAur+oDc/0DNCvYv9ReoU70=",
      "url": "_framework/Microsoft.JSInterop.WebAssembly.pxf5p9f275.wasm"
    },
    {
      "hash": "sha256-Ns5VCXLWs9lpLL8YY5V4Z/AKacYDKj4ZVugHzHagUgg=",
      "url": "_framework/MudBlazor.ydca57x7ni.wasm"
    },
    {
      "hash": "sha256-u43JZbhQbMuJiK64FFcuak4GdsUhNWorh4HPjgfCC+E=",
      "url": "_framework/MudBlazorGitHubPages.l8pujtdh37.wasm"
    },
    {
      "hash": "sha256-oaUyoVo2a89AwFRLViIDIdBnhpi17mAo03uxs1QLd2g=",
      "url": "_framework/Serilog.Sinks.BrowserConsole.x47anjwz3v.wasm"
    },
    {
      "hash": "sha256-2+Qj4wYEFirLYjCHxUJSxDTpPzCq6Z0gVmrMrcO7g9c=",
      "url": "_framework/Serilog.ti8gg3xy57.wasm"
    },
    {
      "hash": "sha256-7S7PV9F0uhg1uUyJIaf99L9DYcnEOFeOiquJ4cs32ng=",
      "url": "_framework/System.Collections.Concurrent.1j8rr440h0.wasm"
    },
    {
      "hash": "sha256-a5QF5KJl+3OlIurXlqsRN9vPNNocE9pzDeswbHomPrE=",
      "url": "_framework/System.Collections.Immutable.lomjiokufm.wasm"
    },
    {
      "hash": "sha256-kwDSibzyDoLVxA2ItFytMvMyRjzkTXVOPhh4GtKtH9E=",
      "url": "_framework/System.Collections.NonGeneric.d0m0s1dqrh.wasm"
    },
    {
      "hash": "sha256-SfhstRaY+8MTbkcfwtYQ5qjIOKtQZVROqc3AZOi3vHs=",
      "url": "_framework/System.Collections.Specialized.pskssxivvx.wasm"
    },
    {
      "hash": "sha256-VLqum0c+eOsthJoHKW//ZCVzfD1+EyALglgJjyPDxfw=",
      "url": "_framework/System.Collections.s2zzy70lwa.wasm"
    },
    {
      "hash": "sha256-UK+J/g58lnN0cn707WR5PdM77Oj4soM0NJK+8PVkMyw=",
      "url": "_framework/System.ComponentModel.Annotations.styc8j8rs9.wasm"
    },
    {
      "hash": "sha256-d6mngQLBkZJN+NvDJ6jZrIifLJoVCrc82Y2fj1ugTbs=",
      "url": "_framework/System.ComponentModel.Primitives.veidnp9gbo.wasm"
    },
    {
      "hash": "sha256-R5Q43tCwXxOopIJNrZo6pvnEdguXXeoTBExrp5CbfJ4=",
      "url": "_framework/System.ComponentModel.TypeConverter.t7evqecong.wasm"
    },
    {
      "hash": "sha256-6ezadFy7yEZhtzFCy/7fvvR1GyTYnCFzbq/d0Qphkn0=",
      "url": "_framework/System.ComponentModel.lhrz3xbrnu.wasm"
    },
    {
      "hash": "sha256-AybkzEOl56Vl43cNhRpd0OeWVN0QWnX6+5QuDBmDWoQ=",
      "url": "_framework/System.Console.zkpi4kkdp3.wasm"
    },
    {
      "hash": "sha256-H1CHBmaAMS4PKAPtP+BRNwndUH6Sgof2IjdMGHxUFvI=",
      "url": "_framework/System.IO.Pipelines.j7hw5n5kz8.wasm"
    },
    {
      "hash": "sha256-X0a9XCxzg7147yI7arpzGyjWGz+dCqQN877S/Vpqahc=",
      "url": "_framework/System.Linq.Expressions.7y16z9zsqs.wasm"
    },
    {
      "hash": "sha256-Nxd4pcsC1dKC2Qex4HAt0QzDH8M1NrLXCjCrpHoMNys=",
      "url": "_framework/System.Linq.tzgriigqkw.wasm"
    },
    {
      "hash": "sha256-K9fbUHZYDY9cbGXl2qb7fcREJHV/eV/KaODaqEeuncY=",
      "url": "_framework/System.Memory.rghra3t197.wasm"
    },
    {
      "hash": "sha256-MuIBShdkd3uBiCmENmDEXcV3gM9ETKBrgfOBbG7pucw=",
      "url": "_framework/System.Net.Http.qdes2txg95.wasm"
    },
    {
      "hash": "sha256-pSdnjYgJc+hNq1q/ZNeofRaYvOCBNL1mHFHoF/j+a8Y=",
      "url": "_framework/System.Net.Primitives.xpspmtm8v8.wasm"
    },
    {
      "hash": "sha256-NNpxg2BCbHj4Zr/kIrJWSR8BudUZyYv7b5OVeC2do1M=",
      "url": "_framework/System.ObjectModel.grb5bwbh8r.wasm"
    },
    {
      "hash": "sha256-/eEaRKBrDnZ4g2ylHNz8wyetp7v+1cP40UGOpaT1f04=",
      "url": "_framework/System.Private.CoreLib.5est5qizbh.wasm"
    },
    {
      "hash": "sha256-RCRmQ5ennDNxD9sBQVM2gIguk1LBrdNSvn9yo0v/Wls=",
      "url": "_framework/System.Private.Uri.k4mtrxv0b8.wasm"
    },
    {
      "hash": "sha256-wqfILadLLKdooVusvPcbEZBkeJ+9Yu23S7S8YQQEyLY=",
      "url": "_framework/System.Runtime.InteropServices.JavaScript.q2qvulo9k9.wasm"
    },
    {
      "hash": "sha256-DA2gXaAY3AE26LPKLlJOntOIGkTqVsOHaPZik3pmvvI=",
      "url": "_framework/System.Runtime.wrehk5iv1p.wasm"
    },
    {
      "hash": "sha256-1pYnog+hAQYG5AmoN8yPu2sN7VE8tXMsT6EUst0eUEo=",
      "url": "_framework/System.Text.Encodings.Web.az6magofqp.wasm"
    },
    {
      "hash": "sha256-DsgphtmDDXcv6BKMzDcF8duvmErzdl23DnSVROfGduU=",
      "url": "_framework/System.Text.Json.m6qyjrds8o.wasm"
    },
    {
      "hash": "sha256-XbtuwntXqbsS8vMASAWcB/qRTxCmL76vIWD6HAQL0ks=",
      "url": "_framework/System.Text.RegularExpressions.pldmx7dvtj.wasm"
    },
    {
      "hash": "sha256-XEsgkzB/5E/EJIekQAKL/++ZBvHe055n9Zo6Q2Ce2Zo=",
      "url": "_framework/System.Threading.cy526l72bt.wasm"
    },
    {
      "hash": "sha256-jdi196RMQvJqOZVnwRK7DGSWJifChhgNljcOjGeHSUY=",
      "url": "_framework/System.t8xd33e5pv.wasm"
    },
    {
      "hash": "sha256-9/Tg3Bv6noid1Buqvska4XtNFDX7sUrIOdx9Xrhq6PI=",
      "url": "_framework/blazor.boot.json"
    },
    {
      "hash": "sha256-+vIfWRbrna1rF+s8xknbrluJxgPx4vfKB0WJ74HdICo=",
      "url": "_framework/blazor.webassembly.js"
    },
    {
      "hash": "sha256-wYjSscllRgsaXH0VUEf8zSZw/5lACwcJOUm+1THG5bk=",
      "url": "_framework/dotnet.js"
    },
    {
      "hash": "sha256-coMLV6FWuhuuALO2KjsfpfVb/JjxzsjCBeeVdI0vo/w=",
      "url": "_framework/dotnet.native.eoyceprv6h.wasm"
    },
    {
      "hash": "sha256-BTZWVYmjU3il0nhi+FV9dvzO3XWNw9R+7u8lgvJ8AL8=",
      "url": "_framework/dotnet.native.fjwdof7fuz.js"
    },
    {
      "hash": "sha256-Isv/63htfX73xgn3/2cZMtk4S8xBcbmlXRgJMDv4mhI=",
      "url": "_framework/dotnet.runtime.ew19f13umk.js"
    },
    {
      "hash": "sha256-SZLtQnRc0JkwqHab0VUVP7T3uBPSeYzxzDnpxPpUnHk=",
      "url": "_framework/icudt_CJK.tjcz0u77k5.dat"
    },
    {
      "hash": "sha256-8fItetYY8kQ0ww6oxwTLiT3oXlBwHKumbeP2pRF4yTc=",
      "url": "_framework/icudt_EFIGS.tptq2av103.dat"
    },
    {
      "hash": "sha256-L7sV7NEYP37/Qr2FPCePo5cJqRgTXRwGHuwF5Q+0Nfs=",
      "url": "_framework/icudt_no_CJK.lfu7j35m59.dat"
    },
    {
      "hash": "sha256-+A9GJSL1F7E2tMCpF5MhfSLW2Gd35PbafP4B4Z7MEcE=",
      "url": "appsettings.json"
    },
    {
      "hash": "sha256-yis2dNdJ6e9R472mcuwUOsxBPCQX3snSMmHAL3zu2D8=",
      "url": "css/app.css"
    },
    {
      "hash": "sha256-4mWsDy3aHl36ZbGt8zByK7Pvd4kRUoNgTYzRnwmPHwg=",
      "url": "favicon.png"
    },
    {
      "hash": "sha256-DbpQaq68ZSb5IoPosBErM1QWBfsbTxpJqhU0REi6wP4=",
      "url": "icon-192.png"
    },
    {
      "hash": "sha256-oEo6d+KqX5fjxTiZk/w9NB3Mi0+ycS5yLwCKwr4IkbA=",
      "url": "icon-512.png"
    },
    {
      "hash": "sha256-LV3+f00+twyg9GdkcdZgHL9eNsYya/KVnqdVOAG71Os=",
      "url": "index.html"
    },
    {
      "hash": "sha256-VSQRX1zufPPfljeh63jtX4Vvpz7IiZ3mWL3FRcPG7gM=",
      "url": "manifest.webmanifest"
    }
  ]
};
