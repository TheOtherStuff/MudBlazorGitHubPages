self.assetsManifest = {
  "version": "dbW1Wikx",
  "assets": [
    {
      "hash": "sha256-Ps2EqpQtAHIfcMzWG8A9KuCME6yn86porJbKiOVBYYc=",
      "url": "404.html"
    },
    {
      "hash": "sha256-UVy3L6kXaa89JN6tg+EbiLCuVLpkmxOoG6sAi7Bb9uc=",
      "url": "BlazorWasmPreRendering.Build.lfyg69o9wu.lib.module.js"
    },
    {
      "hash": "sha256-poV4ELCt5FQ5ItXigsTvFDRnFsaBxnHpwAAXEZ0ho7k=",
      "url": "MudBlazorGitHubPages.styles.css"
    },
    {
      "hash": "sha256-KGcaExjPdLVQUK4LLvcVezhWrWHUpbcKNRc2A3KmGPU=",
      "url": "_content/MudBlazor/MudBlazor.min.css"
    },
    {
      "hash": "sha256-zR6goaoMpR/YVMMSTfCmVNo3kuPgOkjF/ovhkUhAkbk=",
      "url": "_content/MudBlazor/MudBlazor.min.js"
    },
    {
      "hash": "sha256-OaMAAd5n7ORfyur5e3QIyEVKJ76MKIvwbg7/icnnYcU=",
      "url": "_framework/Blazored.LocalStorage.12n6dz54qr.wasm"
    },
    {
      "hash": "sha256-kD5zwaHQ83R4Pk2GPA+DPIfPAuOlYHFtQQIaJ49JkO0=",
      "url": "_framework/Microsoft.AspNetCore.Components.Forms.oyz28tk53q.wasm"
    },
    {
      "hash": "sha256-ZNtPoG/OXlGREvZqZcwyiM9Lp8nDIJzF0/94KITxFig=",
      "url": "_framework/Microsoft.AspNetCore.Components.Web.od3atmaw9k.wasm"
    },
    {
      "hash": "sha256-6ddqnnMMDWpbA2mlFstbX/o5sj7qgUVd5t6EiLfEbMY=",
      "url": "_framework/Microsoft.AspNetCore.Components.WebAssembly.t3m4f0aulk.wasm"
    },
    {
      "hash": "sha256-xQ+9SSn1VCvG3sxnEQpkj3TwNqkmAk/dCGIdcuRUwBo=",
      "url": "_framework/Microsoft.AspNetCore.Components.b8x4rdutcl.wasm"
    },
    {
      "hash": "sha256-3u6fVOwmdwoWQ6/9H0X5hvRs5otVuH8/4lj1PBjHBs4=",
      "url": "_framework/Microsoft.Extensions.Configuration.Abstractions.6ythxrbuxt.wasm"
    },
    {
      "hash": "sha256-fuKpDFdnuA10QXoAvDUZklISrEUAEH9od88sNC7TgLs=",
      "url": "_framework/Microsoft.Extensions.Configuration.Binder.mqgfwo2xzl.wasm"
    },
    {
      "hash": "sha256-R8Rvf+ufvlMX05PSWGUXwGm3hty6uCI9EtqBH2FpDIQ=",
      "url": "_framework/Microsoft.Extensions.Configuration.Json.vejc7kiu4g.wasm"
    },
    {
      "hash": "sha256-+8GdfYwxibM+Tvy+lXvsyXm6YW3CihUN4umxhg0g0UQ=",
      "url": "_framework/Microsoft.Extensions.Configuration.r8o1xobbxj.wasm"
    },
    {
      "hash": "sha256-m9k4pt1S3OsB7nhPn3Spu1JjG5ixGwaWDws5UBzaZjs=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.3ajkzukr0v.wasm"
    },
    {
      "hash": "sha256-0S8+xplhSQmarJJdn4vmu4EsexndHPXAV+EW1kLsQ/A=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.Abstractions.vw5lz7suyp.wasm"
    },
    {
      "hash": "sha256-PkwLOyrHX2POJ7In/xwUvSjwfdKGqLQI6MU2nA8GVKw=",
      "url": "_framework/Microsoft.Extensions.Localization.Abstractions.ae89paw0py.wasm"
    },
    {
      "hash": "sha256-6UgMJoVZBfDdfzYR0aKVK6BWArxpXC1qiQDDjiXw/L4=",
      "url": "_framework/Microsoft.Extensions.Localization.bvn14pws96.wasm"
    },
    {
      "hash": "sha256-IBz22Shp9d3U133Ro2cidS9BOLRPLaxzlHhs5E+8XTE=",
      "url": "_framework/Microsoft.Extensions.Logging.Abstractions.82d3ni0iun.wasm"
    },
    {
      "hash": "sha256-Nw6fMz9mMm8SS3pPrUsobEC9zzLKC6AKDJhHRldk9VA=",
      "url": "_framework/Microsoft.Extensions.Logging.zh7psstrkj.wasm"
    },
    {
      "hash": "sha256-AmK5n6+U3/TZLOrVpiIo8BOymvR7teo9Z2xKXf82gDI=",
      "url": "_framework/Microsoft.Extensions.Options.q5fxbq8vi3.wasm"
    },
    {
      "hash": "sha256-QeF3pj2LH3LcaB6cg9nSyYQ6/Pf6RbTkLakVnAwVPXo=",
      "url": "_framework/Microsoft.Extensions.Primitives.vga3bvc9pt.wasm"
    },
    {
      "hash": "sha256-N8RKL2Eil4ZFxIkWa6Uig12+nRHOstda562q7GCs9fE=",
      "url": "_framework/Microsoft.JSInterop.WebAssembly.nsfh695mwg.wasm"
    },
    {
      "hash": "sha256-0fcrZvooTfVqJLa+J7kOHXH4P9wP4/FapnIfV5ehd3Q=",
      "url": "_framework/Microsoft.JSInterop.hc5bsvhmbu.wasm"
    },
    {
      "hash": "sha256-KKTe04wMbD0/NPHtY0ISG2RZRLWUiGDIo77IgCJDcCs=",
      "url": "_framework/MudBlazor.szm74sss83.wasm"
    },
    {
      "hash": "sha256-Qvst03mQzJUxQsIjSRtguLjtTS2ufNnqiKtAjOvn/Rc=",
      "url": "_framework/MudBlazorGitHubPages.aek0cik91f.wasm"
    },
    {
      "hash": "sha256-RBzG9qYc803aFPcilb57plWWaoD45kCfwn37T8PfCSY=",
      "url": "_framework/Serilog.4yb545qr6j.wasm"
    },
    {
      "hash": "sha256-oaUyoVo2a89AwFRLViIDIdBnhpi17mAo03uxs1QLd2g=",
      "url": "_framework/Serilog.Sinks.BrowserConsole.x47anjwz3v.wasm"
    },
    {
      "hash": "sha256-SwZDz50ko1Wqr4rcM3Zvxwg/4oV8OpKrBDbG5rPAtH4=",
      "url": "_framework/System.Collections.Concurrent.11xercfr4q.wasm"
    },
    {
      "hash": "sha256-xYmTNlmpW78wcmETdUx+o59kOKPo36ZZHzmhj/q5F+0=",
      "url": "_framework/System.Collections.Immutable.dyr121ydf3.wasm"
    },
    {
      "hash": "sha256-ybw1NKbJxAhZzQKe1jBvxZFjXdyBU6vzM268PlEy6ec=",
      "url": "_framework/System.Collections.NonGeneric.55xkw62b0i.wasm"
    },
    {
      "hash": "sha256-Xcd72r/Z6Y68wlDzUcmO6JNpwgJLKsipcUq0+JP9gWo=",
      "url": "_framework/System.Collections.Specialized.nrw3kjn5pv.wasm"
    },
    {
      "hash": "sha256-KqNLkCMS8WAvCb+Nl/ao8DX83f4zgFuXG89Yz6KIg1c=",
      "url": "_framework/System.Collections.i2licv8i8w.wasm"
    },
    {
      "hash": "sha256-PGoXnF48TXj9sDlylt0eQ/tBOjJYX/64Tc/4hU4tta0=",
      "url": "_framework/System.ComponentModel.05pujupo27.wasm"
    },
    {
      "hash": "sha256-gE61NG0iQRO+IXVQ58dV7nUNEFwGVd3b5MvWcWL5ALg=",
      "url": "_framework/System.ComponentModel.Annotations.ch5b5bdrp8.wasm"
    },
    {
      "hash": "sha256-LsmJfEfWkhWucGUW61mmewbXdwfgFO53s1kC9dFTOpw=",
      "url": "_framework/System.ComponentModel.Primitives.mng6d4qtpr.wasm"
    },
    {
      "hash": "sha256-ed4wD0MXh8AeMdsjGy7co7umhpFMDKgdikW6CUkFQlI=",
      "url": "_framework/System.ComponentModel.TypeConverter.dvhk35bas4.wasm"
    },
    {
      "hash": "sha256-6hSzHgNbc2cJS0tLTWYyDFobMRz7IgqCI3nkHMeUyNA=",
      "url": "_framework/System.Console.asjzu2y6ad.wasm"
    },
    {
      "hash": "sha256-TrsEpPyio4eRSE7Wb7CdsGyGh3jcWRwzDDkcEp42Lxc=",
      "url": "_framework/System.Diagnostics.DiagnosticSource.ae3ec8dz20.wasm"
    },
    {
      "hash": "sha256-vB/mHpU8YWqbonbePTX22jmIRwgl+Gn2euzReK4v7es=",
      "url": "_framework/System.IO.Pipelines.8brogkqzjr.wasm"
    },
    {
      "hash": "sha256-EOQaQtO2uOAxf2m2T27ce4EnfPqy2MUa8qTQkq+pGmI=",
      "url": "_framework/System.Linq.Expressions.s1p9137441.wasm"
    },
    {
      "hash": "sha256-qdxJrwd0Xi8RofV8YONqqL6noo4gkXZNAh+P7qOD5Po=",
      "url": "_framework/System.Linq.x6jm24sx47.wasm"
    },
    {
      "hash": "sha256-AlZfojZm8NVTzn3cQgdwVfw30NPw6JL18s6LcbhbDOM=",
      "url": "_framework/System.Memory.edyw47qxtr.wasm"
    },
    {
      "hash": "sha256-SN3xREGLMZ4urYFOX4YGJNvHlvQnd7sswd5KevY3WT4=",
      "url": "_framework/System.Net.Http.o8dhoaknvo.wasm"
    },
    {
      "hash": "sha256-bZIyo1/j633N5pQMd0MwhjszHTrpQognOO74FxR9NLI=",
      "url": "_framework/System.Net.Primitives.baq20ve775.wasm"
    },
    {
      "hash": "sha256-JEtFuU4HZIIu9lQgPf4TOdbPwBsV/MQIALa5c75OL8Q=",
      "url": "_framework/System.ObjectModel.cmkzocrqkq.wasm"
    },
    {
      "hash": "sha256-78sSgSQCfH7Cs6Ig0cA/s6T9qNkTa4EmKFv6EnEuGSQ=",
      "url": "_framework/System.Private.CoreLib.p66nt2303c.wasm"
    },
    {
      "hash": "sha256-JVodBSutX1ZxqJvl0Bh055YOpA6ZJWLlqzpbs/R82Mo=",
      "url": "_framework/System.Private.Uri.58s9bynx2c.wasm"
    },
    {
      "hash": "sha256-iTel8M+hoSI92c0jJFjN3ENcbqXnumik9GyNDAB4CIA=",
      "url": "_framework/System.Runtime.InteropServices.JavaScript.lpvs49i9za.wasm"
    },
    {
      "hash": "sha256-zNHhM/bvIv4zQgzTsXJ67eOo5wSrQ0WFougU0SWv3RA=",
      "url": "_framework/System.Runtime.gn8oc1itaj.wasm"
    },
    {
      "hash": "sha256-OMv0m78kVb0fejHBkAFQR8ppLcZiL/cZYoK1uiRS3rY=",
      "url": "_framework/System.Security.Cryptography.8w3aldlzuj.wasm"
    },
    {
      "hash": "sha256-J9Dql/M4bGzvzKFvTEG4VbH03ZLP3CmgnjaNzGb8DIs=",
      "url": "_framework/System.Text.Encodings.Web.1ypetucuor.wasm"
    },
    {
      "hash": "sha256-ePBAe0VExFpPusnc0hC3g5Twl3Sptv9G5kQ9g05V7fg=",
      "url": "_framework/System.Text.Json.kpmumj6fxn.wasm"
    },
    {
      "hash": "sha256-RBBgfeKnW+669u64orqbqK+GyhKB4SjQGfno2q6bYcs=",
      "url": "_framework/System.Text.RegularExpressions.0f65kz093l.wasm"
    },
    {
      "hash": "sha256-fcZeJpcx95Puk/XzRsdrgEiNvFAMILZMz6hfkexPKp8=",
      "url": "_framework/System.Threading.7jdwdkbyqt.wasm"
    },
    {
      "hash": "sha256-Sd3s9Vn4Uscsky7aa9pkHZrTKzPZT0ckLQ5cMvbAis0=",
      "url": "_framework/System.l5g27qddaj.wasm"
    },
    {
      "hash": "sha256-3lCWrko3zwspV40aQhs2S/IMkRSarnHRKIdkHhuXIBA=",
      "url": "_framework/blazor.webassembly.js"
    },
    {
      "hash": "sha256-Ldl36Sd4hJvOIGkHTEMfG+r0MeQ7Xdsddw9qefO/bOM=",
      "url": "_framework/dotnet.js"
    },
    {
      "hash": "sha256-0Yl9EiFVGdspgCM8yZBNr+XYVmAIu3wvJhd4CNuCZUQ=",
      "url": "_framework/dotnet.native.10leos28m3.js"
    },
    {
      "hash": "sha256-PAYgI4Dg8I+aN97kewi3mZKqOYDvwjSquOQP83rB7bc=",
      "url": "_framework/dotnet.native.8ncvguitov.wasm"
    },
    {
      "hash": "sha256-yJvgPPUUvavYVmu9VD/fYtMcoEnLVaB0Cr7JAE29btw=",
      "url": "_framework/dotnet.runtime.o0qy896u8v.js"
    },
    {
      "hash": "sha256-SZLtQnRc0JkwqHab0VUVP7T3uBPSeYzxzDnpxPpUnHk=",
      "url": "_framework/icudt_CJK.tjcz0u77k5.dat"
    },
    {
      "hash": "sha256-8fItetYY8kQ0ww6oxwTLiT3oXlBwHKumbeP2pRF4yTc=",
      "url": "_framework/icudt_EFIGS.tptq2av103.dat"
    },
    {
      "hash": "sha256-L7sV7NEYP37/Qr2FPCePo5cJqRgTXRwGHuwF5Q+0Nfs=",
      "url": "_framework/icudt_no_CJK.lfu7j35m59.dat"
    },
    {
      "hash": "sha256-+A9GJSL1F7E2tMCpF5MhfSLW2Gd35PbafP4B4Z7MEcE=",
      "url": "appsettings.json"
    },
    {
      "hash": "sha256-yis2dNdJ6e9R472mcuwUOsxBPCQX3snSMmHAL3zu2D8=",
      "url": "css/app.css"
    },
    {
      "hash": "sha256-4mWsDy3aHl36ZbGt8zByK7Pvd4kRUoNgTYzRnwmPHwg=",
      "url": "favicon.png"
    },
    {
      "hash": "sha256-DbpQaq68ZSb5IoPosBErM1QWBfsbTxpJqhU0REi6wP4=",
      "url": "icon-192.png"
    },
    {
      "hash": "sha256-oEo6d+KqX5fjxTiZk/w9NB3Mi0+ycS5yLwCKwr4IkbA=",
      "url": "icon-512.png"
    },
    {
      "hash": "sha256-S1iML/1WNKqGdCxdEGQDpIL0WV2xQKdpw/x0ooUYcH8=",
      "url": "index.html"
    },
    {
      "hash": "sha256-VSQRX1zufPPfljeh63jtX4Vvpz7IiZ3mWL3FRcPG7gM=",
      "url": "manifest.webmanifest"
    }
  ]
};
