self.assetsManifest = {
  "version": "hwnzTiZU",
  "assets": [
    {
      "hash": "sha256-47DEQpj8HBSa+/TImW+5JCeuQeRkm5NMpJWZG3hSuFU=",
      "url": ".nojekyll"
    },
    {
      "hash": "sha256-Ps2EqpQtAHIfcMzWG8A9KuCME6yn86porJbKiOVBYYc=",
      "url": "404.html"
    },
    {
      "hash": "sha256-poV4ELCt5FQ5ItXigsTvFDRnFsaBxnHpwAAXEZ0ho7k=",
      "url": "MudBlazorGitHubPages.styles.css"
    },
    {
      "hash": "sha256-UVy3L6kXaa89JN6tg+EbiLCuVLpkmxOoG6sAi7Bb9uc=",
      "url": "_content/BlazorWasmPreRendering.Build/BlazorWasmPreRendering.Build.lfyg69o9wu.lib.module.js"
    },
    {
      "hash": "sha256-NgHobvE5wu6MFuX0QImF1lk8IP4UUN3UDirKa0WQVYc=",
      "url": "_content/MudBlazor/MudBlazor.min.css"
    },
    {
      "hash": "sha256-TOPYwKltorv5iM1JqqzJayZWZx7LFnfSq2AhkWFNwrg=",
      "url": "_content/MudBlazor/MudBlazor.min.js"
    },
    {
      "hash": "sha256-9j4iJEwca5bjLN0jWGV0/0hXXIig9zItgbG2WbVWRE0=",
      "url": "_framework/Blazored.LocalStorage.aspas9o5sr.wasm"
    },
    {
      "hash": "sha256-vyNNDKTlbd3lO81Cq9QJv4bJJ+lYT8w20Yf0IhorV+E=",
      "url": "_framework/Microsoft.AspNetCore.Components.Forms.xwqw8hmtxg.wasm"
    },
    {
      "hash": "sha256-gPw79NDyRn+pBW33uBDR8yV7nTEEQLwASNhSHWbFlT8=",
      "url": "_framework/Microsoft.AspNetCore.Components.Web.w883vi7hcg.wasm"
    },
    {
      "hash": "sha256-R3TuadFJVJ+Zn99p8DE9bQ1/cnkEfsdZEWLas29/RGE=",
      "url": "_framework/Microsoft.AspNetCore.Components.WebAssembly.tfo8ugcukz.wasm"
    },
    {
      "hash": "sha256-+BrSvsDeo5hUTORETwW6r2aLCf8M0DRdGdJASsUT5SM=",
      "url": "_framework/Microsoft.AspNetCore.Components.wylvefjwr1.wasm"
    },
    {
      "hash": "sha256-E7cHeEGs6Mw8kFTGMX+gOcr2uDl3mia87rJ3uABbhQk=",
      "url": "_framework/Microsoft.Extensions.Configuration.Abstractions.r6mz0bls6u.wasm"
    },
    {
      "hash": "sha256-1+a/TBtwdysVfrMf6UOfa+s+uaGtKjm+Y3GOUW3U9pQ=",
      "url": "_framework/Microsoft.Extensions.Configuration.Binder.zxl31pzqgu.wasm"
    },
    {
      "hash": "sha256-4DE0/WhaMaELUHzK5BQiiG9nOM0Z1qBgxqSSGRu8ESM=",
      "url": "_framework/Microsoft.Extensions.Configuration.Json.080jiixfv5.wasm"
    },
    {
      "hash": "sha256-ccUQy6bgJcb9fQMno+ahljqCPSvNEvPLJQ0l5HVaBfw=",
      "url": "_framework/Microsoft.Extensions.Configuration.jvaq5v0ejy.wasm"
    },
    {
      "hash": "sha256-+TYftnpuawSVU4BKQRqWN+FwcPtVPqDHguupiwkWf0Y=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.78esmno2al.wasm"
    },
    {
      "hash": "sha256-U8RTzVjWEbUU+H0NRp4y4gaHcwO6X5R9jzgc62Xcn7U=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.Abstractions.joukolixxe.wasm"
    },
    {
      "hash": "sha256-c29RmalAkIt6iWvUr31OkflYCKyzyO6vyplry2MXz1I=",
      "url": "_framework/Microsoft.Extensions.Localization.Abstractions.f105w8ezv4.wasm"
    },
    {
      "hash": "sha256-6+hWNu6IOJjQ2Q0U7rYk73IzqF8az4duNUgL24LiFUo=",
      "url": "_framework/Microsoft.Extensions.Localization.h5tijc5bhn.wasm"
    },
    {
      "hash": "sha256-WrKJx/HWOM/AQrKzp9OxuFoozxPExQnGxK44U30zAWQ=",
      "url": "_framework/Microsoft.Extensions.Logging.Abstractions.2ttb6foo5w.wasm"
    },
    {
      "hash": "sha256-Pl2WiwNj6e3gS79SBDqlxw9YpsuYy7WkMnAo/OD64ig=",
      "url": "_framework/Microsoft.Extensions.Logging.i4ete6t9pk.wasm"
    },
    {
      "hash": "sha256-uGUgktOUxpprtf8CDihhay/2lQqWId9cu01c0aop69M=",
      "url": "_framework/Microsoft.Extensions.Options.0q5rkj5gn3.wasm"
    },
    {
      "hash": "sha256-yvecHeiA1zrGVgFTUfyhbENy78UmpPDX6HLAdxYRbtA=",
      "url": "_framework/Microsoft.Extensions.Primitives.ihsc9l5exw.wasm"
    },
    {
      "hash": "sha256-63bzxZLVvNOmTsso6iLrptxGmKBQh2HUIEGtPUrRPeQ=",
      "url": "_framework/Microsoft.JSInterop.WebAssembly.lsljofql11.wasm"
    },
    {
      "hash": "sha256-ptUNJaBEpUOucicx4NcvwqBakxD5WmCj8gsUw9SNUfY=",
      "url": "_framework/Microsoft.JSInterop.uv2bbr5r9r.wasm"
    },
    {
      "hash": "sha256-PvdrR4W3dDduRmDjTpjSZ5Avm0l6FxcHgyIT66kE8Ns=",
      "url": "_framework/MudBlazor.a15bdrxakt.wasm"
    },
    {
      "hash": "sha256-TpiAyT/VwY+ATPEKQzuPMspZWhrQ5g6QojoUTvoAQEs=",
      "url": "_framework/MudBlazorGitHubPages.y0havxhdtm.wasm"
    },
    {
      "hash": "sha256-+Kw6K2veEF68HjH+KczVc/5JkXf5p9dLrspV5siihGc=",
      "url": "_framework/Serilog.Sinks.BrowserConsole.k1xnc0w3gl.wasm"
    },
    {
      "hash": "sha256-4Ji1V3z8DabsozUMiJilAv2YF8kw5OpUlwcajVdJg38=",
      "url": "_framework/Serilog.cppcqwcrh3.wasm"
    },
    {
      "hash": "sha256-BnqRcUwv4PlvZ4Pg6IkXNp3uPaH4SgMLrBcsl2/fIOk=",
      "url": "_framework/System.Collections.Concurrent.m8p18jh8zx.wasm"
    },
    {
      "hash": "sha256-P+qo0C1RDJzJv5CwF77/cbAykxUpccGwb947OZWTZ60=",
      "url": "_framework/System.Collections.Immutable.lvpjwbm67y.wasm"
    },
    {
      "hash": "sha256-Em4nLcC/m1oEHGEF1cvb5PTyXuMMbMA4TN+xuF1m62A=",
      "url": "_framework/System.Collections.NonGeneric.m7goumxkhb.wasm"
    },
    {
      "hash": "sha256-PwPvpe3AzBEsANZ/QRogc6IR4GKrho+JOYUM9v2eIiw=",
      "url": "_framework/System.Collections.Specialized.fc8wxghcdy.wasm"
    },
    {
      "hash": "sha256-WdM4kn4Z0TulO54WlB6g3Rji9Zi+p/l0SUa/YuRJ/IA=",
      "url": "_framework/System.Collections.va2cuu414k.wasm"
    },
    {
      "hash": "sha256-JNR/o2tUFaDeOk9pghPZD2sAdWEKA2OUJ2ONln9UeD0=",
      "url": "_framework/System.ComponentModel.076m38u6l8.wasm"
    },
    {
      "hash": "sha256-gRKZ411ozlBHdtcHGdJZmt5yGYiBRVV51yOXLlTq7P8=",
      "url": "_framework/System.ComponentModel.Annotations.dhdttba5q8.wasm"
    },
    {
      "hash": "sha256-qnAA7pSDGq8s2XonCgevz4UOkvwxIBCncIqOz4XJUfU=",
      "url": "_framework/System.ComponentModel.Primitives.6p6zse1nm6.wasm"
    },
    {
      "hash": "sha256-gzgNLk4LdXiG7XMpssKpEl/BfnQNtGNSuxnV0mHVStc=",
      "url": "_framework/System.ComponentModel.TypeConverter.xjf7h3yb5i.wasm"
    },
    {
      "hash": "sha256-8R0VT2AMP7l8M2YCXqC8m3KP2mspqgx3Kjdqh8D3de4=",
      "url": "_framework/System.Console.d9ymjpp199.wasm"
    },
    {
      "hash": "sha256-Oa+YYnDz7Y7QdrHu4dSaDBejVaRUi9/iGQU2lLGJaPU=",
      "url": "_framework/System.IO.Pipelines.z9mcxtggrr.wasm"
    },
    {
      "hash": "sha256-XFcwHf7Jqw6Ha08B764TuIxlgDaAkkXifDSqpvf5U3I=",
      "url": "_framework/System.Linq.Expressions.ksmp9c9e80.wasm"
    },
    {
      "hash": "sha256-wYqw8j91yIvWXynIDUltLnxhI3XK6hxM+PAHxrk8UsA=",
      "url": "_framework/System.Linq.j7rali5z0g.wasm"
    },
    {
      "hash": "sha256-IbNzqrqQ8JHZ9L289pVfCgReWZcB2Ep1186GiaDDN9o=",
      "url": "_framework/System.Memory.r5p2hwfhqx.wasm"
    },
    {
      "hash": "sha256-mO2B/+uXN7gzgyMidUcCJ3Mb51bQ+6rZ0OG5ofURUhs=",
      "url": "_framework/System.Net.Http.cvbabqwszi.wasm"
    },
    {
      "hash": "sha256-CibhF/tAsBSNw4oixhbAHkiVEhVm+U+OpcYR5MktQXU=",
      "url": "_framework/System.Net.Primitives.avlxts81n2.wasm"
    },
    {
      "hash": "sha256-s/h3AqEnguZXHVAHYmFZ2YEw4UeRdF4NkOyd9kujTvk=",
      "url": "_framework/System.ObjectModel.jga7ow7b1w.wasm"
    },
    {
      "hash": "sha256-ly2HDJPGtfjCkjNC7HHlV2PJBINlajGL90vsK5CwICk=",
      "url": "_framework/System.Private.CoreLib.dfgtm5ph0g.wasm"
    },
    {
      "hash": "sha256-iOSUhUWi5m+zIKeX6cSbd6Qog1vlTiJsAa5Vm+65V78=",
      "url": "_framework/System.Private.Uri.0meavxl7ml.wasm"
    },
    {
      "hash": "sha256-mpqADt50XBKv0jfHL/pqKFHx+EiZ5JyoisOFgHWrrAY=",
      "url": "_framework/System.Runtime.2hwwtvyfxo.wasm"
    },
    {
      "hash": "sha256-g/aUkR3AQnsITw/gxxNj+qpKuLo5ESBNMANpklb/Yhk=",
      "url": "_framework/System.Runtime.InteropServices.JavaScript.nf54u5jbpe.wasm"
    },
    {
      "hash": "sha256-9CGBGIIvl+r6UWI6Ao3ovVPFawCi0MZWFhPQp4JHt4Q=",
      "url": "_framework/System.Text.Encodings.Web.grj4h07yaw.wasm"
    },
    {
      "hash": "sha256-9qcuGFc5SmcyLFTyJOFDcDZ3TdI+kUYaP2nneo/Svhs=",
      "url": "_framework/System.Text.Json.qbl4zgqig6.wasm"
    },
    {
      "hash": "sha256-pAQdrss3RGWbtddzdovGg1N9D+i+35mVAVN2njEBHsM=",
      "url": "_framework/System.Text.RegularExpressions.k6zpxrvqij.wasm"
    },
    {
      "hash": "sha256-F5PSI/gBuwoWEF7SbdO7+2/Lo9hw0ISBKug8avOpxP0=",
      "url": "_framework/System.Threading.vuopdrx302.wasm"
    },
    {
      "hash": "sha256-v1DeJU321NUwk3KJ0Lf8lQA3zwRfrxNommmMBs1s3Gk=",
      "url": "_framework/System.f0fr8djds0.wasm"
    },
    {
      "hash": "sha256-AJfd4nCbjxGx0OKxebjG+dVl1yG0P67xWJDgtPL8u68=",
      "url": "_framework/blazor.boot.json"
    },
    {
      "hash": "sha256-+vIfWRbrna1rF+s8xknbrluJxgPx4vfKB0WJ74HdICo=",
      "url": "_framework/blazor.webassembly.js"
    },
    {
      "hash": "sha256-5TAd2is0AgjjYIAuEN8Bd5ZPoTk8dKE9RRtIQr4H5Lw=",
      "url": "_framework/dotnet.js"
    },
    {
      "hash": "sha256-LkNoY38EBYJmp5vZX00wbkMMdtNPiAlc2dCzrDWVEJM=",
      "url": "_framework/dotnet.native.if0ghrqpu8.js"
    },
    {
      "hash": "sha256-X11saxqchDQJy//n7kDcjtgZ69ibVtQzCwXLuRzp6yw=",
      "url": "_framework/dotnet.native.vg8ezqh67k.wasm"
    },
    {
      "hash": "sha256-dCmS9Zx4egtLYSUgTI3R6gMS+Yg8MkzxW1CgEMJKAEw=",
      "url": "_framework/dotnet.runtime.cymp1amu5g.js"
    },
    {
      "hash": "sha256-SZLtQnRc0JkwqHab0VUVP7T3uBPSeYzxzDnpxPpUnHk=",
      "url": "_framework/icudt_CJK.tjcz0u77k5.dat"
    },
    {
      "hash": "sha256-8fItetYY8kQ0ww6oxwTLiT3oXlBwHKumbeP2pRF4yTc=",
      "url": "_framework/icudt_EFIGS.tptq2av103.dat"
    },
    {
      "hash": "sha256-L7sV7NEYP37/Qr2FPCePo5cJqRgTXRwGHuwF5Q+0Nfs=",
      "url": "_framework/icudt_no_CJK.lfu7j35m59.dat"
    },
    {
      "hash": "sha256-+A9GJSL1F7E2tMCpF5MhfSLW2Gd35PbafP4B4Z7MEcE=",
      "url": "appsettings.json"
    },
    {
      "hash": "sha256-yis2dNdJ6e9R472mcuwUOsxBPCQX3snSMmHAL3zu2D8=",
      "url": "css/app.css"
    },
    {
      "hash": "sha256-4mWsDy3aHl36ZbGt8zByK7Pvd4kRUoNgTYzRnwmPHwg=",
      "url": "favicon.png"
    },
    {
      "hash": "sha256-DbpQaq68ZSb5IoPosBErM1QWBfsbTxpJqhU0REi6wP4=",
      "url": "icon-192.png"
    },
    {
      "hash": "sha256-oEo6d+KqX5fjxTiZk/w9NB3Mi0+ycS5yLwCKwr4IkbA=",
      "url": "icon-512.png"
    },
    {
      "hash": "sha256-LV3+f00+twyg9GdkcdZgHL9eNsYya/KVnqdVOAG71Os=",
      "url": "index.html"
    },
    {
      "hash": "sha256-VSQRX1zufPPfljeh63jtX4Vvpz7IiZ3mWL3FRcPG7gM=",
      "url": "manifest.webmanifest"
    }
  ]
};
